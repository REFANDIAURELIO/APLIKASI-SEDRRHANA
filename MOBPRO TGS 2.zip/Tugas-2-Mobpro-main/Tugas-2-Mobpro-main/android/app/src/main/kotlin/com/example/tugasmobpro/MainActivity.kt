package com.example.tugasmobpro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
